package com.example.neurolife

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
