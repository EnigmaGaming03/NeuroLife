import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/neuro_life_response.dart';

class PippinChatScreen extends StatefulWidget {
  const PippinChatScreen({super.key});

  @override
  State<PippinChatScreen> createState() => _PippinChatScreenState();
}

class _PippinChatScreenState extends State<PippinChatScreen> {
  final TextEditingController _controller = TextEditingController();
  NeuroLifeResponse? _response;
  bool _loading = false;

  void _sendMessage() async {
    setState(() => _loading = true);
    final response = await ApiService.sendMessage(_controller.text);
    setState(() {
      _response = response;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Talk to Aws Bedrock🐧')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
                controller: _controller,
                decoration: InputDecoration(labelText: 'How are you feeling?')),
            const SizedBox(height: 10),
            ElevatedButton(
                onPressed: _loading ? null : _sendMessage,
                child: const Text("Talk to Pippin")),
            const SizedBox(height: 20),
            if (_loading) CircularProgressIndicator(),
            if (_response != null)
              Expanded(
                child: ListView(
                  children: [
                    Text("Pippin says: ${_response!.message}"),
                    const SizedBox(height: 10),
                    Text("🎵 Music Recommendations:"),
                    ..._response!.musicRecommendations.map(
                        (r) => Text("- ${r.title} by ${r.authorOrArtist}")),
                    const SizedBox(height: 10),
                    Text("📚 Book Recommendations:"),
                    ..._response!.bookRecommendations.map(
                        (r) => Text("- ${r.title} by ${r.authorOrArtist}")),
                    const SizedBox(height: 10),
                    Text("⏰ Reminders:"),
                    ..._response!.reminders
                        .map((r) => Text("- ${r.type} at ${r.time}")),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}
