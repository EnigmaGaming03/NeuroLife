import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/neuro_life_response.dart';

class ApiService {
  static const String endpoint =
      'https://mq6tw33dc7.execute-api.us-west-2.amazonaws.com/prod/neuro-life';
  static const String apiKey = 'kh1t0V65PvcSBxAieuYE6Ik2mrfj0eQ3pbAsn7Ye';

  static Future<NeuroLifeResponse?> sendMessage(String message) async {
    try {
      final response = await http.post(
        Uri.parse(endpoint),
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
        },
        body: jsonEncode({'message': message}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        //print('Status: ${response.statusCode}');
        //print('Headers: ${response.headers}');
        //print('Body: ${response.body}');
        return NeuroLifeResponse.fromJson(data);
      } else {
        print('Failed response: ${response.statusCode}');
        //print('Headers: ${response.headers}');
      }
    } catch (e) {
      print('API error: $e');
    }
    return null;
  }
}
