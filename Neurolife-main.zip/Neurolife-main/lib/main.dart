import 'dart:ui';

import 'package:amplify_api/amplify_api.dart';
import 'dart:convert';
import 'package:amplify_auth_cognito/amplify_auth_cognito.dart';
import 'package:amplify_authenticator/amplify_authenticator.dart';
import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'amplifyconfiguration.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'screens/pippin_chat.dart';
import 'package:fl_chart/fl_chart.dart';

final storage = FlutterSecureStorage();

class SambaNovaService {
  final String baseUrl =
      'https://api.sambanova.ai/v1/chat/completions'; // Replace with actual endpoint
  final String apiKey;

  SambaNovaService({required this.apiKey});

  Future<String> sendMessage(String message) async {
    final response = await http.post(
      Uri.parse(baseUrl),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({
        'messages': [
          {'role': 'user', 'content': message}
        ],
        'model': 'DeepSeek-V3-0324' // Replace with correct model ID
      }),
    );

    if (response.statusCode == 200) {
      final decoded = jsonDecode(response.body);
      return decoded['choices'][0]['message']['content'];
    } else {
      throw Exception('Failed to connect to SambaNova: ${response.body}');
    }
  }
}

Future<void> storeSambaNovaApiKey(String apiKey) async {
  await storage.write(key: 'sambanova_api_key', value: apiKey);
}

Future<String?> getSambaNovaApiKey() async {
  return await storage.read(key: 'sambanova_api_key');
}

Future<void> exampleUsage() async {
  await storeSambaNovaApiKey('573cbf94-f7c1-46e6-a367-65cb85872811');
  // ignore: unused_local_variable
  String? apiKey = await getSambaNovaApiKey();
  //print('Retrieved API Key: $apiKey');
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _configureAmplify();
  runApp(const NeuroLifeApp());
}

Future<void> _configureAmplify() async {
  // Add your Amplify configuration here
  // For example, you might want to initialize Amplify with your AWS configuration
  // await Amplify.addPlugin(AmplifyAuthCognito());
  // await Amplify.configure(amplifyconfig);
  try {
    // Create the API plugin.
    //
    // If `ModelProvider.instance` is not available, try running
    // `amplify codegen models` from the root of your project.
    final api = AmplifyAPI();
    // Create the Auth plugin.
    final auth = AmplifyAuthCognito();

    // Add the plugins and configure Amplify for your app.
    await Amplify.addPlugins([api, auth]);
    await Amplify.configure(amplifyconfig);

    safePrint('Successfully configured');
  } on Exception catch (e) {
    safePrint('Error configuring Amplify: $e');
  }
}

class NeuroLifeApp extends StatefulWidget {
  const NeuroLifeApp({super.key});
  @override
  State<NeuroLifeApp> createState() => HomePageState();
}

class HomePageState extends State<NeuroLifeApp> {
  // GoRouter configuration
  static final _router = GoRouter(
    routes: [
      GoRoute(
        path: '/',
        builder: (context, state) => const HomePage(),
      ),
    ],
  );

  @override
  void initState() {
    super.initState();
    initializeApiKey();
  }

  Future<void> initializeApiKey() async {
    // ignore: unused_local_variable
    String? key = await getSambaNovaApiKey();
    //print('Loaded API Key: $key');
  }

  @override
  Widget build(BuildContext context) {
    return Authenticator(
      child: MaterialApp.router(
        routerConfig: _router,
        debugShowCheckedModeBanner: false,
        title: 'NeuroLife',
        theme: ThemeData.dark().copyWith(
          colorScheme: ColorScheme.dark(
            primary: Colors.blueAccent,
            secondary: Colors.cyanAccent,
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blueAccent,
              foregroundColor: Colors.white,
            ),
          ),
        ),
        builder: Authenticator.builder(),
      ),
    );
  }
}

enum MoodLevel {
  veryUnpleasant,
  unpleasant,
  neutral,
  pleasant,
  veryPleasant,
}

extension MoodLevelExtension on MoodLevel {
  String get displayText {
    switch (this) {
      case MoodLevel.veryUnpleasant:
        return "😫 Very Unpleasant";
      case MoodLevel.unpleasant:
        return "🙁 Unpleasant";
      case MoodLevel.neutral:
        return "😐 Neutral";
      case MoodLevel.pleasant:
        return "🙂 Pleasant";
      case MoodLevel.veryPleasant:
        return "😊 Very Pleasant";
    }
  }

  static MoodLevel fromScore(double score) {
    if (score >= 1 && score <= 2.5) return MoodLevel.veryUnpleasant;
    if (score > 2.5 && score <= 4.5) return MoodLevel.unpleasant;
    if (score > 4.5 && score <= 6.5) return MoodLevel.neutral;
    if (score > 6.5 && score <= 8.5) return MoodLevel.pleasant;
    if (score > 8.5 && score <= 10) return MoodLevel.veryPleasant;
    return MoodLevel.neutral;
  }
}

class MoodChart extends StatelessWidget {
  const MoodChart({super.key});

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.7,
      child: LineChart(
        LineChartData(
          titlesData: FlTitlesData(
            leftTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: true),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  const days = [
                    'Mon',
                    'Tue',
                    'Wed',
                    'Thu',
                    'Fri',
                    'Sat',
                    'Sun'
                  ];
                  return SideTitleWidget(
                    axisSide: meta.axisSide,
                    child: Text(days[value.toInt() % days.length]),
                  );
                },
              ),
            ),
          ),
          borderData: FlBorderData(show: true),
          gridData: FlGridData(show: true),
          lineBarsData: [
            LineChartBarData(
              isCurved: true,
              spots: [
                FlSpot(0, 5),
                FlSpot(1, 6),
                FlSpot(2, 7.5),
                FlSpot(3, 5.8),
                FlSpot(4, 6.2),
                FlSpot(5, 7),
                FlSpot(6, 8),
              ],
              barWidth: 4,
              isStrokeCapRound: true,
              color: Colors.blue,
              dotData: FlDotData(show: true),
            ),
          ],
        ),
      ),
    );
  }
}

// --- MedicationEntry Model ---
class MedicationEntry {
  final String id;
  String name;
  DateTime time;

  MedicationEntry({
    required this.id,
    required this.name,
    required this.time,
  });
}

class LoadingScreen extends StatelessWidget {
  const LoadingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Stack(
        children: [
          // Background image
          Positioned.fill(
            child: Image.asset(
              'assets/imgAssets/bgMountainImg7.png',
              fit: BoxFit.cover,
            ),
          ),

          // Blur effect over image
          Positioned.fill(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 4.0, sigmaY: 4.0),
              child: Container(
                color: Color.fromRGBO(0, 0, 0, 0.1), // Optional tint
              ),
            ),
          ),

          // Foreground content
          SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(0),
              children: [
                const SizedBox(height: 40),

                Text(
                  'Neurolife, Your Lifestyle Companion',
                  style: TextStyle(
                      fontSize: 19,
                      fontFamily: 'LeagueSpartan',
                      fontWeight: FontWeight.bold,
                      color: const Color.fromARGB(255, 0, 0, 0)),
                  textAlign: TextAlign.center,
                ),

                const SizedBox(height: 15),

                Text(
                  "What's on Your Mind Today?",
                  style: TextStyle(
                    fontSize: 55,
                    fontFamily: 'LeagueSpartan',
                    fontWeight: FontWeight.w700,
                    color: const Color.fromARGB(255, 0, 0, 0),
                  ),
                  textAlign: TextAlign.center,
                ),

                const SizedBox(height: 70),

                // Placeholder black boxes

                Container(
                  height: 170,
                  width: double.infinity, // Ensures full width
                  color: Colors.black,
                  child: Image.asset('assets/imgAssets/booklistMockup.png'),
                ),

                Container(
                  height: 170,
                  width: double.infinity, // Ensures full width
                  color: Colors.black,
                  child: Image.asset('assets/imgAssets/songlistMockup.png'),
                ),

                const SizedBox(height: 50),

                ElevatedButton(
                  child: Text('🧠 Use NeuroBuddy Agentic AI'),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const PippinChatScreen()),
                  ),
                ),

                const SizedBox(height: 16),

                ElevatedButton(
                  child: Text('💬 Chat with Neurobuddy'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ChatScreen(
                          apiKey: '573cbf94-f7c1-46e6-a367-65cb85872811',
                        ),
                      ),
                    );
                  },
                ),

                const SizedBox(height: 16),

                Container(
                  color: Colors.black,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      minimumSize: Size(double.infinity, 50),
                    ),
                    onPressed: () => _showMoodLoggingChoice(context),
                    child: Text('📊 Daily Mood Analysis',
                        style: TextStyle(fontSize: 18)),
                  ), // Ensures full width
                ),

                const SizedBox(height: 16),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    minimumSize: Size(double.infinity, 50),
                  ),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => EmergencyHelpView()),
                  ),
                  child:
                      Text('🚨 Emergency Info', style: TextStyle(fontSize: 18)),
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ChatScreen extends StatefulWidget {
  final String apiKey;
  const ChatScreen({super.key, required this.apiKey});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, String>> _messages = [];
  late SambaNovaService _service;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _service = SambaNovaService(apiKey: widget.apiKey);
  }

  Future<void> _sendMessage() async {
    final input = _controller.text.trim();
    if (input.isEmpty) return;

    setState(() {
      _messages.add({'role': 'user', 'content': input});
      _loading = true;
    });

    _controller.clear();

    try {
      final response = await _service.sendMessage(input);
      setState(() {
        _messages.add({'role': 'ai', 'content': response});
      });
    } catch (e) {
      setState(() {
        _messages.add({'role': 'ai', 'content': '⚠️ Error: $e'});
      });
    }

    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Chat with NeuroBuddy')),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final msg = _messages[index];
                return ListTile(
                  title: Align(
                    alignment: msg['role'] == 'user'
                        ? Alignment.centerRight
                        : Alignment.centerLeft,
                    child: Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: msg['role'] == 'user'
                            ? Colors.blue.shade100
                            : Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(msg['content'] ?? ''),
                    ),
                  ),
                );
              },
            ),
          ),
          if (_loading) CircularProgressIndicator(),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: 'Ask something...',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                SizedBox(width: 8),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

void _showMoodLoggingChoice(BuildContext context) {
  showModalBottomSheet(
    context: context,
    builder: (_) => MoodLoggingChoiceView(),
  );
}

// --- EmergencyHelpView ---
class EmergencyHelpView extends StatefulWidget {
  const EmergencyHelpView({super.key});

  @override
  EmergencyHelpViewState createState() => EmergencyHelpViewState();
}

class EmergencyHelpViewState extends State<EmergencyHelpView> {
  final _formKey = GlobalKey<FormState>();

  // Simulate persisted personal info with simple state variables:
  String name = '';
  String age = '';
  String gender = '';
  String conditions = '';
  String allergies = '';
  String medications = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Emergency'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('🚨 Emergency info',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text(
                'Here you can provide emergency contacts, coping tips, or a quick contact form.',
                style: TextStyle(fontSize: 16)),
            Divider(height: 40),
            Text('🧾 Personal Info',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  _buildTextField('Name', (v) => name = v, initialValue: name),
                  _buildTextField('Age', (v) => age = v,
                      initialValue: age, keyboardType: TextInputType.number),
                  _buildTextField('Gender', (v) => gender = v,
                      initialValue: gender),
                  _buildTextField('Medical Conditions', (v) => conditions = v,
                      initialValue: conditions),
                  _buildTextField('Allergies', (v) => allergies = v,
                      initialValue: allergies),
                  _buildTextField('Medications', (v) => medications = v,
                      initialValue: medications),
                ],
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              onPressed: () {
                // Simulate saving to persistent storage (shared_preferences or similar)
                // Here just pop for demo
                if (_formKey.currentState!.validate()) {
                  _formKey.currentState!.save();
                  Navigator.pop(context);
                }
              },
              child: Text('✅ Save Info', style: TextStyle(fontSize: 18)),
            ),
            Divider(height: 40),
            Text('🛟 Emergency Copilot',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text(
              'Detects signs of distress using voice, text, and biometric cues. This feature helps trigger alerts or prepare emergency info if distress is detected. Please turn this feature on if you are working out, hiking or participating in any physical activity.',
              style: TextStyle(fontSize: 16, color: Colors.grey[700]),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Emergency Copilot activated')),
                );
              },
              child:
                  Text('🎙 Start Monitoring', style: TextStyle(fontSize: 18)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, Function(String) onSaved,
      {String? initialValue, TextInputType keyboardType = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        initialValue: initialValue,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(),
        ),
        keyboardType: keyboardType,
        onSaved: (v) => onSaved(v ?? ''),
      ),
    );
  }
}

// --- MoodLoggingChoiceView ---
class MoodLoggingChoiceView extends StatelessWidget {
  const MoodLoggingChoiceView({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.all(20),
        height: 500,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Select Logging Type',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MoodAnalysisView(
                          loggingType: 'Today', timestamp: DateTime.now()),
                    ),
                  );
                },
                child: Text('🕒 Log for Today', style: TextStyle(fontSize: 18)),
              ),
              SizedBox(height: 12),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MoodAnalysisView(
                          loggingType: 'Week', timestamp: null),
                    ),
                  );
                },
                child: Text('📅 Log for This Week',
                    style: TextStyle(fontSize: 18)),
              ),
              SizedBox(height: 12),
              SizedBox(
                height: 200,
                child: MoodChart(),
              ),
              SizedBox(height: 12),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Cancel',
                    style: TextStyle(color: Colors.red, fontSize: 16)),
              )
            ],
          ),
        ));
  }
}

// --- MoodAnalysisView ---
class MoodAnalysisView extends StatefulWidget {
  final String loggingType;
  final DateTime? timestamp;

  const MoodAnalysisView(
      {super.key, required this.loggingType, required this.timestamp});

  @override
  MoodAnalysisViewState createState() => MoodAnalysisViewState();
}

class MoodAnalysisViewState extends State<MoodAnalysisView> {
  double moodValue = 5;
  Set<String> selectedFeelings = {};
  String aiResponse = "Your AI result will appear here.";

  late Map<MoodLevel, List<String>> feelingsByMood;

  @override
  void initState() {
    super.initState();

    feelingsByMood = {
      MoodLevel.veryUnpleasant: [
        "Hopeless",
        "Exhausted",
        "Angry",
        "Panicked",
        "Irritable",
        "Ashamed",
        "Worried",
        "Grieving"
      ],
      MoodLevel.unpleasant: [
        "Tired",
        "Anxious",
        "Frustrated",
        "Sad",
        "Stressed",
        "Disappointed",
        "Lonely"
      ],
      MoodLevel.neutral: [
        "Bored",
        "Meh",
        "Indifferent",
        "Calm",
        "Blank",
        "Okay",
        "Relaxed"
      ],
      MoodLevel.pleasant: [
        "Content",
        "Motivated",
        "Inspired",
        "Optimistic",
        "Grateful",
        "Excited",
        "Focused"
      ],
      MoodLevel.veryPleasant: [
        "Euphoric",
        "Joyful",
        "Energetic",
        "Elated",
        "Proud",
        "Confident",
        "Connected"
      ],
    };
  }

  List<String> get allFeelings =>
      feelingsByMood.values.expand((list) => list).toSet().toList()..sort();

  MoodLevel get moodLevel => MoodLevelExtension.fromScore(moodValue);

  List<String> get recommendedFeelings => feelingsByMood[moodLevel] ?? [];

  String get formattedTimestamp {
    if (widget.timestamp == null) return "N/A";
    return "${widget.timestamp!.day.toString().padLeft(2, '0')} "
        "${_monthName(widget.timestamp!.month)} "
        "${widget.timestamp!.year}, "
        "${widget.timestamp!.hour % 12 == 0 ? 12 : widget.timestamp!.hour % 12}:${widget.timestamp!.minute.toString().padLeft(2, '0')} "
        "${widget.timestamp!.hour >= 12 ? "PM" : "AM"}";
  }

  String _monthName(int month) {
    const months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec"
    ];
    return months[month - 1];
  }

  Color dynamicMoodColor() {
    switch (moodLevel) {
      case MoodLevel.veryUnpleasant:
        final opacity = 1 - ((moodValue - 1) / (2.5 - 1)) * 0.6;
        return Colors.orange;
      case MoodLevel.unpleasant:
        final opacity = 0.4 - ((moodValue - 2.6) / (4.5 - 2.6)) * 0.3;
        return Colors.orange;
      case MoodLevel.neutral:
        final opacity = 0.3 + ((moodValue - 4.6) / (6.5 - 4.6)) * 0.7;
        return Colors.blue;
      case MoodLevel.pleasant:
        final opacity = 0.5 + ((moodValue - 6.6) / (8.5 - 6.6)) * 0.5;
        return Colors.green;
      case MoodLevel.veryPleasant:
        return Colors.green;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mood Analysis'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Save', style: TextStyle(color: Colors.white)),
          )
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue.shade200, Colors.blue.shade100],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              Text(
                'Mood Analysis (${widget.loggingType})',
                style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
              if (widget.loggingType == 'Today') ...[
                SizedBox(height: 6),
                Text(
                  '🕒 Time: $formattedTimestamp',
                  style: TextStyle(fontSize: 16, color: Colors.white70),
                ),
              ],
              SizedBox(height: 20),
              Text('How are you feeling today?',
                  style: TextStyle(fontSize: 20, color: Colors.white)),
              Slider(
                min: 1,
                max: 10,
                divisions: 5,
                value: moodValue,
                activeColor: Colors.white,
                inactiveColor: Colors.white38,
                onChanged: (value) {
                  setState(() {
                    moodValue = value;
                    selectedFeelings.clear();
                  });
                },
              ),
              SizedBox(height: 8),
              Text(
                'Mood Level: ${moodLevel.displayText}',
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
              SizedBox(height: 20),
              if (recommendedFeelings.isNotEmpty) ...[
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Recommended feelings:',
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white)),
                ),
                SizedBox(height: 8),
                feelingsGrid(recommendedFeelings),
                SizedBox(height: 20),
              ],
              Align(
                alignment: Alignment.centerLeft,
                child: Text('All feelings:',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white)),
              ),
              SizedBox(height: 8),
              feelingsGrid(allFeelings),
              SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      selectedFeelings.isEmpty ? Colors.white : Colors.white,
                ),
                onPressed: selectedFeelings.isEmpty ? null : analyzeMood,
                child:
                    Text('Analyze Mood', style: TextStyle(color: Colors.blue)),
              ),
              SizedBox(height: 20),
              Text(
                aiResponse,
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),
              SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget feelingsGrid(List<String> feelings) {
    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: feelings.map((feeling) {
        final selected = selectedFeelings.contains(feeling);
        return GestureDetector(
          onTap: () {
            setState(() {
              if (selected) {
                selectedFeelings.remove(feeling);
              } else {
                selectedFeelings.add(feeling);
              }
            });
          },
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            constraints: BoxConstraints(minWidth: 120),
            decoration: BoxDecoration(
              color: selected ? dynamicMoodColor() : dynamicMoodColor(),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              feeling,
              style: TextStyle(color: Colors.white),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        );
      }).toList(),
    );
  }

  void analyzeMood() {
    final selected = selectedFeelings.toList()..sort();
    setState(() {
      aiResponse =
          "🧠 Analyzing ${widget.loggingType} mood: ${moodLevel.displayText}\n🧾 Feelings: ${selected.join(', ')}";
      if (widget.loggingType == 'Today' && widget.timestamp != null) {
        aiResponse += "\n🕒 Logged at: $formattedTimestamp";
      }
    });
  }
}

class MoodAnalysisPage extends StatefulWidget {
  const MoodAnalysisPage({super.key});

  @override
  MoodAnalysisPageState createState() => MoodAnalysisPageState();
}

class MoodAnalysisPageState extends State<MoodAnalysisPage> {
  double moodValue = 5;
  String moodDescription = '';
  String aiResponse = 'Your AI result will appear here.';
  @override
  void initState() {
    super.initState();
  }

  Widget _buildRow({
    required String title,
    required String description,
    required String amount,
    TextStyle? style,
  }) {
    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            textAlign: TextAlign.center,
            style: style,
          ),
        ),
        Expanded(
          child: Text(
            description,
            textAlign: TextAlign.center,
            style: style,
          ),
        ),
        Expanded(
          child: Text(
            amount,
            textAlign: TextAlign.center,
            style: style,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Mood Analysis')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Text("How are you feeling today?",
                  style: TextStyle(fontSize: 22)),
              Slider(
                value: moodValue,
                onChanged: (value) => setState(() => moodValue = value),
                min: 1,
                max: 10,
                divisions: 9,
                label: moodValue.toStringAsFixed(0),
              ),
              Text("Mood Level: $moodLabel", style: TextStyle(fontSize: 18)),
              SizedBox(height: 16),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Describe your mood',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
                onChanged: (val) => moodDescription = val,
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: moodDescription.trim().isEmpty ? null : analyzeMood,
                child: Text('Analyze Mood'),
              ),
              SizedBox(height: 16),
              Text(aiResponse, textAlign: TextAlign.center),
              const SizedBox(height: 30),
              _buildRow(
                title: 'Title',
                description: 'Description',
                amount: 'Amount',
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ],
          ),
        ),
      ),
    );
  }

  String get moodLabel {
    if (moodValue <= 2.5) return '😫 Very Unpleasant';
    if (moodValue <= 4.5) return '🙁 Unpleasant';
    if (moodValue <= 6.5) return '😐 Neutral';
    if (moodValue <= 8.5) return '🙂 Pleasant';
    return '😊 Very Pleasant';
  }

  void analyzeMood() {
    setState(() {
      aiResponse =
          '🧠 Analyzing mood: ${moodLabel.split(" ").last}\n📝 Description: $moodDescription';
    });
  }
}
