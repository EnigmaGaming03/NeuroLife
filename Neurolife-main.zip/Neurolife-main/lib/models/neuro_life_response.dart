class Recommendation {
  final String title;
  final String authorOrArtist;

  Recommendation({required this.title, required this.authorOrArtist});

  factory Recommendation.fromJson(Map<String, dynamic> json,
      {bool isMusic = false}) {
    return Recommendation(
      title: json['title'],
      authorOrArtist: isMusic ? json['artist'] : json['author'],
    );
  }
}

class Reminder {
  final String type;
  final String time;

  Reminder({required this.type, required this.time});

  factory Reminder.fromJson(Map<String, dynamic> json) {
    return Reminder(type: json['type'], time: json['time']);
  }
}

class NeuroLifeResponse {
  final String message;
  final List<Recommendation> musicRecommendations;
  final List<Recommendation> bookRecommendations;
  final List<Reminder> reminders;

  NeuroLifeResponse({
    required this.message,
    required this.musicRecommendations,
    required this.bookRecommendations,
    required this.reminders,
  });

  factory NeuroLifeResponse.fromJson(Map<String, dynamic> json) {
    return NeuroLifeResponse(
      message: json['message'] ?? '',
      musicRecommendations: (json['music_recommendations'] as List<dynamic>?)
              ?.map((e) => Recommendation.fromJson(e, isMusic: true))
              .toList() ??
          [],
      bookRecommendations: (json['book_recommendations'] as List<dynamic>?)
              ?.map((e) => Recommendation.fromJson(e))
              .toList() ??
          [],
      reminders: (json['reminders'] as List<dynamic>?)
              ?.map((e) => Reminder.fromJson(e))
              .toList() ??
          [],
    );
  }
}
